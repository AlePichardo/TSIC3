﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ChangeTexture : MonoBehaviour
{
	public Texture Tex1, Tex2, Tex3;
    private int a = 0;
	Renderer MeshRenderer;

    // Start is called before the first frame update
    void Start()
    {
        MeshRenderer = GetComponent<Renderer> ();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void ChangeTex() {
    	switch(a) {
    		case 0:
    			MeshRenderer.material.SetTexture("_MainTex", Tex1);
    			a = 1;
    		break;

    		case 1:
    			MeshRenderer.material.SetTexture("_MainTex", Tex2);
    			a = 2;
    		break;

    		case 2:
    			MeshRenderer.material.SetTexture("_MainTex", Tex3);
    			a = 3;
    		break;

    		default:
    		break;
    	}
    }
}
