﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif



#include "codegen/il2cpp-codegen-metadata.h"





IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END




// 0x00000001 System.Void Google.ProtocolBuffers.ExtensionRegistry::.ctor(System.Collections.Generic.Dictionary`2<System.Object,System.Collections.Generic.Dictionary`2<System.String,Google.ProtocolBuffers.IGeneratedExtensionLite>>,System.Collections.Generic.Dictionary`2<Google.ProtocolBuffers.ExtensionRegistry_ExtensionIntPair,Google.ProtocolBuffers.IGeneratedExtensionLite>,System.Boolean)
extern void ExtensionRegistry__ctor_mF4099F865F601799805753719699B51A1F8BF699 (void);
// 0x00000002 Google.ProtocolBuffers.ExtensionRegistry Google.ProtocolBuffers.ExtensionRegistry::get_Empty()
extern void ExtensionRegistry_get_Empty_mC76700E7B42667A40F8433F271510D22D330BF29 (void);
// 0x00000003 Google.ProtocolBuffers.ExtensionRegistry Google.ProtocolBuffers.ExtensionRegistry::CreateInstance()
extern void ExtensionRegistry_CreateInstance_mBE28073ABF59242395C31E9DFAC9B7FEA784BCB7 (void);
// 0x00000004 System.Void Google.ProtocolBuffers.ExtensionRegistry::.cctor()
extern void ExtensionRegistry__cctor_mD36BBA297AACB67B5478C47FD5AFF2775B3CD987 (void);
// 0x00000005 System.Int32 Google.ProtocolBuffers.ExtensionRegistry_ExtensionIntPair::GetHashCode()
extern void ExtensionIntPair_GetHashCode_m1D21D9A1D7D3E5A2ECEE9383AF118B4F3D82D299_AdjustorThunk (void);
// 0x00000006 System.Boolean Google.ProtocolBuffers.ExtensionRegistry_ExtensionIntPair::Equals(System.Object)
extern void ExtensionIntPair_Equals_m224294E7F9245BCED0B0DD828A59F136212F97C4_AdjustorThunk (void);
// 0x00000007 System.Boolean Google.ProtocolBuffers.ExtensionRegistry_ExtensionIntPair::Equals(Google.ProtocolBuffers.ExtensionRegistry_ExtensionIntPair)
extern void ExtensionIntPair_Equals_m8276EEC0E6636D5526116D44148196AAC89AADB2_AdjustorThunk (void);
// 0x00000008 System.Void Google.ProtocolBuffers.CodedInputStream::.ctor(System.Byte[],System.Int32,System.Int32)
extern void CodedInputStream__ctor_m25002ECFA7626046D8621E40717D71243CDBE91E (void);
// 0x00000009 System.Void Google.ProtocolBuffers.CodedInputStream::.ctor(System.IO.Stream)
extern void CodedInputStream__ctor_m60B9F9B76FAA08808B1243A383E5E2CCCAFFC9F6 (void);
// 0x0000000A System.Boolean Google.ProtocolBuffers.CodedInputStream::get_ReachedLimit()
extern void CodedInputStream_get_ReachedLimit_m8736B51914163DE2A8837C2288A079F06C86FB64 (void);
// 0x0000000B System.Boolean Google.ProtocolBuffers.CodedInputStream::get_IsAtEnd()
extern void CodedInputStream_get_IsAtEnd_m8417EC83EC7CE827735CE42EFF467BDAC85D567E (void);
// 0x0000000C Google.ProtocolBuffers.CodedInputStream Google.ProtocolBuffers.CodedInputStream::CreateInstance(System.IO.Stream)
extern void CodedInputStream_CreateInstance_mED0E557FA356ADBC18ED093E2D7BF13840CF0E44 (void);
// 0x0000000D Google.ProtocolBuffers.CodedInputStream Google.ProtocolBuffers.CodedInputStream::CreateInstance(System.Byte[])
extern void CodedInputStream_CreateInstance_mDCCBF7B8F327F1FDD334431F754FEF73841F3D85 (void);
// 0x0000000E System.Void Google.ProtocolBuffers.CodedInputStream::CheckLastTagWas(System.UInt32)
extern void CodedInputStream_CheckLastTagWas_m0DAA172667D4075A6914716396E1CDFF96CAF5A3 (void);
// 0x0000000F System.Boolean Google.ProtocolBuffers.CodedInputStream::PeekNextTag(System.UInt32&,System.String&)
extern void CodedInputStream_PeekNextTag_m2D28A65E348CF9D6E884D6A4428B385D3B88568F (void);
// 0x00000010 System.Boolean Google.ProtocolBuffers.CodedInputStream::ReadTag(System.UInt32&,System.String&)
extern void CodedInputStream_ReadTag_m23AD3CE9C1EA9C2A60CDF47055EFD90C8478A9F4 (void);
// 0x00000011 System.Boolean Google.ProtocolBuffers.CodedInputStream::ReadFloat(System.Single&)
extern void CodedInputStream_ReadFloat_mD9086AA478EBB9116119E886132EB77A34057BF7 (void);
// 0x00000012 System.Boolean Google.ProtocolBuffers.CodedInputStream::ReadInt64(System.Int64&)
extern void CodedInputStream_ReadInt64_m55FA77E4A4E9CECBEE875A15D592E2310FA3989C (void);
// 0x00000013 System.Boolean Google.ProtocolBuffers.CodedInputStream::ReadInt32(System.Int32&)
extern void CodedInputStream_ReadInt32_m5DFAF195BE1D9460F1054F33F7546C03C5C4BFE4 (void);
// 0x00000014 System.Void Google.ProtocolBuffers.CodedInputStream::ReadMessage(Google.ProtocolBuffers.IBuilderLite,Google.ProtocolBuffers.ExtensionRegistry)
extern void CodedInputStream_ReadMessage_m7DA8CB99856FBF06EB24656EF1C0634F1FDC2BA5 (void);
// 0x00000015 System.Boolean Google.ProtocolBuffers.CodedInputStream::ReadEnum(T&,System.Object&)
// 0x00000016 System.Boolean Google.ProtocolBuffers.CodedInputStream::BeginArray(System.UInt32,System.Boolean&,System.Int32&)
extern void CodedInputStream_BeginArray_m42A2EF56555A3ACE3DE02F1E55991703473174B3 (void);
// 0x00000017 System.Boolean Google.ProtocolBuffers.CodedInputStream::ContinueArray(System.UInt32)
extern void CodedInputStream_ContinueArray_m9E5201C6D13EB4E669B86309DBD08AB6C3AE8C0A (void);
// 0x00000018 System.Boolean Google.ProtocolBuffers.CodedInputStream::ContinueArray(System.UInt32,System.Boolean,System.Int32)
extern void CodedInputStream_ContinueArray_m89C18ABC3064B5E3173D09BFA8FC6263A670B639 (void);
// 0x00000019 System.Void Google.ProtocolBuffers.CodedInputStream::ReadFloatArray(System.UInt32,System.String,System.Collections.Generic.ICollection`1<System.Single>)
extern void CodedInputStream_ReadFloatArray_mF36250455461A4B25D959E30D16B13AF600E384A (void);
// 0x0000001A System.Void Google.ProtocolBuffers.CodedInputStream::ReadMessageArray(System.UInt32,System.String,System.Collections.Generic.ICollection`1<T>,T,Google.ProtocolBuffers.ExtensionRegistry)
// 0x0000001B System.UInt32 Google.ProtocolBuffers.CodedInputStream::SlowReadRawVarint32()
extern void CodedInputStream_SlowReadRawVarint32_m4BD0F8ACC2A9B6335AB0B17D19AFE65109DD63DC (void);
// 0x0000001C System.UInt32 Google.ProtocolBuffers.CodedInputStream::ReadRawVarint32()
extern void CodedInputStream_ReadRawVarint32_m3D50095F615E35805EE5EFF1A95111BEE84A0F83 (void);
// 0x0000001D System.UInt32 Google.ProtocolBuffers.CodedInputStream::ReadRawVarint32(System.IO.Stream)
extern void CodedInputStream_ReadRawVarint32_mEB99186B7A2BBACABCAEFB4579EBA9BB1DBA1265 (void);
// 0x0000001E System.UInt64 Google.ProtocolBuffers.CodedInputStream::ReadRawVarint64()
extern void CodedInputStream_ReadRawVarint64_mDD7099D0590839AFA896E033EECD43E82B834071 (void);
// 0x0000001F System.UInt32 Google.ProtocolBuffers.CodedInputStream::ReadRawLittleEndian32()
extern void CodedInputStream_ReadRawLittleEndian32_m701343A2D5D3D8BBB543E45C171B1251BFD55658 (void);
// 0x00000020 System.UInt64 Google.ProtocolBuffers.CodedInputStream::ReadRawLittleEndian64()
extern void CodedInputStream_ReadRawLittleEndian64_m0DC389BC213758ED97481456E282ED2CF0000E42 (void);
// 0x00000021 System.Int32 Google.ProtocolBuffers.CodedInputStream::PushLimit(System.Int32)
extern void CodedInputStream_PushLimit_m055A0982177C87205DA4AB870A4C0CF56AFE9C7E (void);
// 0x00000022 System.Void Google.ProtocolBuffers.CodedInputStream::RecomputeBufferSizeAfterLimit()
extern void CodedInputStream_RecomputeBufferSizeAfterLimit_m9C20EE52E2D94F82A602FA3EF3DA5CB87E0A2EE7 (void);
// 0x00000023 System.Void Google.ProtocolBuffers.CodedInputStream::PopLimit(System.Int32)
extern void CodedInputStream_PopLimit_m194E43997E0D1E8EF3C6F6A67C7350F60AD92465 (void);
// 0x00000024 System.Boolean Google.ProtocolBuffers.CodedInputStream::RefillBuffer(System.Boolean)
extern void CodedInputStream_RefillBuffer_mAFD4A09A9127023CB6024245B27394DC234C242F (void);
// 0x00000025 System.Byte Google.ProtocolBuffers.CodedInputStream::ReadRawByte()
extern void CodedInputStream_ReadRawByte_m511DFAE58BB34C5CEC4487BEFDD2EB72016E7F70 (void);
// 0x00000026 System.Byte[] Google.ProtocolBuffers.CodedInputStream::ReadRawBytes(System.Int32)
extern void CodedInputStream_ReadRawBytes_m60E3439632092B8C7EE2D22682B7F7DC672184CA (void);
// 0x00000027 System.Boolean Google.ProtocolBuffers.CodedInputStream::SkipField()
extern void CodedInputStream_SkipField_m8D83720F0C50B636EAA76C82C9993FABF8EBF907 (void);
// 0x00000028 System.Void Google.ProtocolBuffers.CodedInputStream::SkipMessage()
extern void CodedInputStream_SkipMessage_mB6E7938C82845EA0474DCCC8122DD5BE8C634DF0 (void);
// 0x00000029 System.Void Google.ProtocolBuffers.CodedInputStream::SkipRawBytes(System.Int32)
extern void CodedInputStream_SkipRawBytes_m8EC3B6FCCE8F72B0DA9DE76DDCE8964904676108 (void);
// 0x0000002A System.Void Google.ProtocolBuffers.CodedInputStream::SkipImpl(System.Int32)
extern void CodedInputStream_SkipImpl_m4CBC750F18077F37088AF8F8A28E664AB323DF88 (void);
// 0x0000002B System.Void Google.ProtocolBuffers.ByteString::.ctor(System.Byte[])
extern void ByteString__ctor_m77972159D66DA7ECFBD8E7B620B65D85B9ACD041 (void);
// 0x0000002C System.Collections.Generic.IEnumerator`1<System.Byte> Google.ProtocolBuffers.ByteString::GetEnumerator()
extern void ByteString_GetEnumerator_mBC3C445EB21B657575B4BA250D0B3816561A4249 (void);
// 0x0000002D System.Collections.IEnumerator Google.ProtocolBuffers.ByteString::System.Collections.IEnumerable.GetEnumerator()
extern void ByteString_System_Collections_IEnumerable_GetEnumerator_m34F2DA34980CB755B3D7B2CBE72FA16ED0B48EBF (void);
// 0x0000002E Google.ProtocolBuffers.CodedInputStream Google.ProtocolBuffers.ByteString::CreateCodedInput()
extern void ByteString_CreateCodedInput_m82BF44BB2E98BE75D8ED0BFBE1373293745309B1 (void);
// 0x0000002F System.Boolean Google.ProtocolBuffers.ByteString::Equals(System.Object)
extern void ByteString_Equals_m4DA87E7B49C2CEA07E21ACA2322430222A9C3163 (void);
// 0x00000030 System.Int32 Google.ProtocolBuffers.ByteString::GetHashCode()
extern void ByteString_GetHashCode_m268B011825773C6512A8370AA00979838849D63C (void);
// 0x00000031 System.Boolean Google.ProtocolBuffers.ByteString::Equals(Google.ProtocolBuffers.ByteString)
extern void ByteString_Equals_mEFC46C0676208219A7AEF437AF30BC0160B87BA8 (void);
// 0x00000032 System.Void Google.ProtocolBuffers.ByteString::.cctor()
extern void ByteString__cctor_mB4E455AD3CC78C9C46FADB102DE08F78400AEEEF (void);
// 0x00000033 System.Void Google.ProtocolBuffers.UninitializedMessageException::.ctor(Google.ProtocolBuffers.IMessageLite)
extern void UninitializedMessageException__ctor_m90F992B8FE15D9561ED07370C274A52EC43736BB (void);
// 0x00000034 Google.ProtocolBuffers.InvalidProtocolBufferException Google.ProtocolBuffers.UninitializedMessageException::AsInvalidProtocolBufferException()
extern void UninitializedMessageException_AsInvalidProtocolBufferException_m9731AF29AD15EF96286EC9A80AC4B2DF39C534A7 (void);
// 0x00000035 TMessage Google.ProtocolBuffers.GeneratedBuilderLite`2::get_MessageBeingBuilt()
// 0x00000036 System.Void Google.ProtocolBuffers.GeneratedBuilderLite`2::.ctor()
// 0x00000037 TBuilder Google.ProtocolBuffers.GeneratedBuilderLite`2::MergeFrom(Google.ProtocolBuffers.IMessageLite)
// 0x00000038 TBuilder Google.ProtocolBuffers.GeneratedBuilderLite`2::MergeFrom(TMessage)
// 0x00000039 System.Boolean Google.ProtocolBuffers.GeneratedBuilderLite`2::ParseUnknownField(Google.ProtocolBuffers.ICodedInputStream,Google.ProtocolBuffers.ExtensionRegistry,System.UInt32,System.String)
// 0x0000003A TMessage Google.ProtocolBuffers.GeneratedBuilderLite`2::BuildParsed()
// 0x0000003B TMessage Google.ProtocolBuffers.GeneratedBuilderLite`2::Build()
// 0x0000003C System.Void Google.ProtocolBuffers.ICodedOutputStream::WriteFloat(System.Int32,System.String,System.Single)
// 0x0000003D System.Void Google.ProtocolBuffers.ICodedOutputStream::WriteInt64(System.Int32,System.String,System.Int64)
// 0x0000003E System.Void Google.ProtocolBuffers.ICodedOutputStream::WriteInt32(System.Int32,System.String,System.Int32)
// 0x0000003F System.Void Google.ProtocolBuffers.ICodedOutputStream::WriteMessage(System.Int32,System.String,Google.ProtocolBuffers.IMessageLite)
// 0x00000040 System.Void Google.ProtocolBuffers.ICodedOutputStream::WriteEnum(System.Int32,System.String,System.Int32,System.Object)
// 0x00000041 System.Void Google.ProtocolBuffers.ICodedOutputStream::WriteMessageArray(System.Int32,System.String,System.Collections.Generic.IEnumerable`1<T>)
// 0x00000042 System.Void Google.ProtocolBuffers.ICodedOutputStream::WritePackedFloatArray(System.Int32,System.String,System.Int32,System.Collections.Generic.IEnumerable`1<System.Single>)
// 0x00000043 System.Void Google.ProtocolBuffers.CodedOutputStream::.ctor(System.Byte[],System.Int32,System.Int32)
extern void CodedOutputStream__ctor_m5440A4DAF33751466097FD4CD85D7A7562BDA564 (void);
// 0x00000044 System.Int32 Google.ProtocolBuffers.CodedOutputStream::get_SpaceLeft()
extern void CodedOutputStream_get_SpaceLeft_mADAF9D8D680791DD50C0ED974809FA602BD2BB8C (void);
// 0x00000045 System.Int32 Google.ProtocolBuffers.CodedOutputStream::ComputeFloatSize(System.Int32,System.Single)
extern void CodedOutputStream_ComputeFloatSize_m590AFD0BAD36720168DBFB2EA91754E846F70BC7 (void);
// 0x00000046 System.Int32 Google.ProtocolBuffers.CodedOutputStream::ComputeInt64Size(System.Int32,System.Int64)
extern void CodedOutputStream_ComputeInt64Size_m469FA3555088F5F6436873B0B862B27DAC90A566 (void);
// 0x00000047 System.Int32 Google.ProtocolBuffers.CodedOutputStream::ComputeInt32Size(System.Int32,System.Int32)
extern void CodedOutputStream_ComputeInt32Size_m81AD208FD9D9AA6BEF44E7DED4F46FA8D6E3390B (void);
// 0x00000048 System.Int32 Google.ProtocolBuffers.CodedOutputStream::ComputeMessageSize(System.Int32,Google.ProtocolBuffers.IMessageLite)
extern void CodedOutputStream_ComputeMessageSize_m8EB8C8EA0C467313A246817B90D1AD63BC4011C9 (void);
// 0x00000049 System.Int32 Google.ProtocolBuffers.CodedOutputStream::ComputeEnumSize(System.Int32,System.Int32)
extern void CodedOutputStream_ComputeEnumSize_mE1251105EDCED82ABE3F9E4E3AA12EBD71949655 (void);
// 0x0000004A System.Int32 Google.ProtocolBuffers.CodedOutputStream::ComputeInt32SizeNoTag(System.Int32)
extern void CodedOutputStream_ComputeInt32SizeNoTag_m370909614401731E07D4DEACEF7488A38A30B01C (void);
// 0x0000004B System.Int32 Google.ProtocolBuffers.CodedOutputStream::ComputeEnumSizeNoTag(System.Int32)
extern void CodedOutputStream_ComputeEnumSizeNoTag_mCB5B90A0B231A5802F44CFC5ADAEB1242F0553C5 (void);
// 0x0000004C System.Int32 Google.ProtocolBuffers.CodedOutputStream::ComputeRawVarint32Size(System.UInt32)
extern void CodedOutputStream_ComputeRawVarint32Size_mBB34A0D2142D18730820495009D674EB2F889E32 (void);
// 0x0000004D System.Int32 Google.ProtocolBuffers.CodedOutputStream::ComputeRawVarint64Size(System.UInt64)
extern void CodedOutputStream_ComputeRawVarint64Size_mA787C8FE03DED2971D70313ABC7B71F37F466B82 (void);
// 0x0000004E System.Int32 Google.ProtocolBuffers.CodedOutputStream::ComputeTagSize(System.Int32)
extern void CodedOutputStream_ComputeTagSize_mE2C32E82317507B0C0E344AC0D218A8F6EA12CBE (void);
// 0x0000004F Google.ProtocolBuffers.CodedOutputStream Google.ProtocolBuffers.CodedOutputStream::CreateInstance(System.Byte[])
extern void CodedOutputStream_CreateInstance_m54CE3BE9AEF110DA1EA545A191E591367E7CA9A6 (void);
// 0x00000050 Google.ProtocolBuffers.CodedOutputStream Google.ProtocolBuffers.CodedOutputStream::CreateInstance(System.Byte[],System.Int32,System.Int32)
extern void CodedOutputStream_CreateInstance_mB40511EA02D789AE51561B3B3A2A0F7A54CC1DD5 (void);
// 0x00000051 System.Void Google.ProtocolBuffers.CodedOutputStream::WriteFloat(System.Int32,System.String,System.Single)
extern void CodedOutputStream_WriteFloat_m3EEF3CB5A52127C6DBE9585F99CDF58B4A7D8DD8 (void);
// 0x00000052 System.Void Google.ProtocolBuffers.CodedOutputStream::WriteInt64(System.Int32,System.String,System.Int64)
extern void CodedOutputStream_WriteInt64_m019539F5E16160623E854D43D7B236ECA542AE0F (void);
// 0x00000053 System.Void Google.ProtocolBuffers.CodedOutputStream::WriteInt32(System.Int32,System.String,System.Int32)
extern void CodedOutputStream_WriteInt32_m882E713613E8F5F75C53B0788BBE02DD6799B6CA (void);
// 0x00000054 System.Void Google.ProtocolBuffers.CodedOutputStream::WriteMessage(System.Int32,System.String,Google.ProtocolBuffers.IMessageLite)
extern void CodedOutputStream_WriteMessage_m0D6B8F598C7EF8006829246B5894C874C4AA96FC (void);
// 0x00000055 System.Void Google.ProtocolBuffers.CodedOutputStream::WriteEnum(System.Int32,System.String,System.Int32,System.Object)
extern void CodedOutputStream_WriteEnum_mB1B7A037BEC4C5488B23CE12848D52AE87D012A2 (void);
// 0x00000056 System.Void Google.ProtocolBuffers.CodedOutputStream::WriteFloatNoTag(System.Single)
extern void CodedOutputStream_WriteFloatNoTag_m237A87522C5A2E3AF41EB69F7B0DF415F7A87B95 (void);
// 0x00000057 System.Void Google.ProtocolBuffers.CodedOutputStream::WriteInt32NoTag(System.Int32)
extern void CodedOutputStream_WriteInt32NoTag_m44A3C8BF676D904191FEA4C1C744449631AE4EA8 (void);
// 0x00000058 System.Void Google.ProtocolBuffers.CodedOutputStream::WriteMessageArray(System.Int32,System.String,System.Collections.Generic.IEnumerable`1<T>)
// 0x00000059 System.Void Google.ProtocolBuffers.CodedOutputStream::WritePackedFloatArray(System.Int32,System.String,System.Int32,System.Collections.Generic.IEnumerable`1<System.Single>)
extern void CodedOutputStream_WritePackedFloatArray_m831FBF27B71E42F6BF8949A3656ADF54E5201301 (void);
// 0x0000005A System.Void Google.ProtocolBuffers.CodedOutputStream::WriteTag(System.Int32,Google.ProtocolBuffers.WireFormat_WireType)
extern void CodedOutputStream_WriteTag_mAD0902B5FFE753EFD6C311DDFB11C77703DE9F31 (void);
// 0x0000005B System.Void Google.ProtocolBuffers.CodedOutputStream::WriteRawVarint32(System.UInt32)
extern void CodedOutputStream_WriteRawVarint32_m600FA15E7AE0A175329E1213BD91F4D27B8F43E7 (void);
// 0x0000005C System.Void Google.ProtocolBuffers.CodedOutputStream::WriteRawVarint64(System.UInt64)
extern void CodedOutputStream_WriteRawVarint64_mEB769FF529708B0B04BAA1FCC5843351E255F681 (void);
// 0x0000005D System.Void Google.ProtocolBuffers.CodedOutputStream::WriteRawByte(System.Byte)
extern void CodedOutputStream_WriteRawByte_m2E7A872FBE5B33184F0106F8797920B7A17A6AA6 (void);
// 0x0000005E System.Void Google.ProtocolBuffers.CodedOutputStream::WriteRawBytes(System.Byte[],System.Int32,System.Int32)
extern void CodedOutputStream_WriteRawBytes_mC6EF30495677ECD22E0F6055388DD33D7592B2B0 (void);
// 0x0000005F System.Void Google.ProtocolBuffers.CodedOutputStream::RefreshBuffer()
extern void CodedOutputStream_RefreshBuffer_m228716090B0D4D7716E2FA4E1EBFCE4061F65B0A (void);
// 0x00000060 System.Void Google.ProtocolBuffers.CodedOutputStream::CheckNoSpaceLeft()
extern void CodedOutputStream_CheckNoSpaceLeft_mC23977D42A81BA5E37063FD8117EC568D90B466B (void);
// 0x00000061 System.Void Google.ProtocolBuffers.CodedOutputStream::.cctor()
extern void CodedOutputStream__cctor_m04BA84AE430F59CB6222197FBEA2E27AD0099507 (void);
// 0x00000062 System.Void Google.ProtocolBuffers.CodedOutputStream_OutOfSpaceException::.ctor()
extern void OutOfSpaceException__ctor_m5B2FF11494FCA787A208E50C60B5D250C87B9249 (void);
// 0x00000063 TMessage Google.ProtocolBuffers.AbstractMessageLite`2::get_DefaultInstanceForType()
// 0x00000064 System.Boolean Google.ProtocolBuffers.AbstractMessageLite`2::get_IsInitialized()
// 0x00000065 System.Int32 Google.ProtocolBuffers.AbstractMessageLite`2::get_SerializedSize()
// 0x00000066 System.Void Google.ProtocolBuffers.AbstractMessageLite`2::.ctor()
// 0x00000067 TBuilder Google.ProtocolBuffers.AbstractMessageLite`2::CreateBuilderForType()
// 0x00000068 TBuilder Google.ProtocolBuffers.AbstractMessageLite`2::ToBuilder()
// 0x00000069 System.Void Google.ProtocolBuffers.AbstractMessageLite`2::WriteTo(Google.ProtocolBuffers.ICodedOutputStream)
// 0x0000006A System.Void Google.ProtocolBuffers.AbstractMessageLite`2::PrintTo(System.IO.TextWriter)
// 0x0000006B System.Byte[] Google.ProtocolBuffers.AbstractMessageLite`2::ToByteArray()
// 0x0000006C Google.ProtocolBuffers.IBuilderLite Google.ProtocolBuffers.AbstractMessageLite`2::Google.ProtocolBuffers.IMessageLite.WeakCreateBuilderForType()
// 0x0000006D System.Void Google.ProtocolBuffers.AbstractMessageLite`2::System.Runtime.Serialization.ISerializable.GetObjectData(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
// 0x0000006E System.Void Google.ProtocolBuffers.AbstractMessageLite`2_SerializationSurrogate::.ctor(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
// 0x0000006F System.Object Google.ProtocolBuffers.AbstractMessageLite`2_SerializationSurrogate::System.Runtime.Serialization.IObjectReference.GetRealObject(System.Runtime.Serialization.StreamingContext)
// 0x00000070 System.Void Google.ProtocolBuffers.AbstractMessageLite`2_SerializationSurrogate::System.Runtime.Serialization.ISerializable.GetObjectData(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
// 0x00000071 System.Void Google.ProtocolBuffers.AbstractMessageLite`2_SerializationSurrogate::.cctor()
// 0x00000072 T Google.ProtocolBuffers.Collections.PopsicleList`1::get_Item(System.Int32)
// 0x00000073 System.Void Google.ProtocolBuffers.Collections.PopsicleList`1::set_Item(System.Int32,T)
// 0x00000074 System.Int32 Google.ProtocolBuffers.Collections.PopsicleList`1::get_Count()
// 0x00000075 System.Boolean Google.ProtocolBuffers.Collections.PopsicleList`1::get_IsReadOnly()
// 0x00000076 System.Void Google.ProtocolBuffers.Collections.PopsicleList`1::.ctor()
// 0x00000077 System.Void Google.ProtocolBuffers.Collections.PopsicleList`1::MakeReadOnly()
// 0x00000078 System.Int32 Google.ProtocolBuffers.Collections.PopsicleList`1::IndexOf(T)
// 0x00000079 System.Void Google.ProtocolBuffers.Collections.PopsicleList`1::Insert(System.Int32,T)
// 0x0000007A System.Void Google.ProtocolBuffers.Collections.PopsicleList`1::RemoveAt(System.Int32)
// 0x0000007B System.Void Google.ProtocolBuffers.Collections.PopsicleList`1::Add(T)
// 0x0000007C System.Void Google.ProtocolBuffers.Collections.PopsicleList`1::Clear()
// 0x0000007D System.Boolean Google.ProtocolBuffers.Collections.PopsicleList`1::Contains(T)
// 0x0000007E System.Void Google.ProtocolBuffers.Collections.PopsicleList`1::CopyTo(T[],System.Int32)
// 0x0000007F System.Boolean Google.ProtocolBuffers.Collections.PopsicleList`1::Remove(T)
// 0x00000080 System.Collections.Generic.IEnumerator`1<T> Google.ProtocolBuffers.Collections.PopsicleList`1::GetEnumerator()
// 0x00000081 System.Collections.IEnumerator Google.ProtocolBuffers.Collections.PopsicleList`1::System.Collections.IEnumerable.GetEnumerator()
// 0x00000082 System.Void Google.ProtocolBuffers.Collections.PopsicleList`1::Add(System.Collections.Generic.IEnumerable`1<T>)
// 0x00000083 System.Void Google.ProtocolBuffers.Collections.PopsicleList`1::ValidateModification()
// 0x00000084 System.Void Google.ProtocolBuffers.Collections.PopsicleList`1::.cctor()
// 0x00000085 System.Collections.Generic.IList`1<T> Google.ProtocolBuffers.Collections.Lists::AsReadOnly(System.Collections.Generic.IList`1<T>)
// 0x00000086 System.Collections.Generic.IList`1<T> Google.ProtocolBuffers.Collections.Lists`1::AsReadOnly(System.Collections.Generic.IList`1<T>)
// 0x00000087 System.Void Google.ProtocolBuffers.Collections.Lists`1::.cctor()
// 0x00000088 TBuilder Google.ProtocolBuffers.AbstractBuilderLite`2::get_ThisBuilder()
// 0x00000089 System.Boolean Google.ProtocolBuffers.AbstractBuilderLite`2::get_IsInitialized()
// 0x0000008A TMessage Google.ProtocolBuffers.AbstractBuilderLite`2::get_DefaultInstanceForType()
// 0x0000008B System.Void Google.ProtocolBuffers.AbstractBuilderLite`2::.ctor()
// 0x0000008C TBuilder Google.ProtocolBuffers.AbstractBuilderLite`2::Clear()
// 0x0000008D TBuilder Google.ProtocolBuffers.AbstractBuilderLite`2::Clone()
// 0x0000008E TMessage Google.ProtocolBuffers.AbstractBuilderLite`2::Build()
// 0x0000008F TMessage Google.ProtocolBuffers.AbstractBuilderLite`2::BuildPartial()
// 0x00000090 TBuilder Google.ProtocolBuffers.AbstractBuilderLite`2::MergeFrom(Google.ProtocolBuffers.IMessageLite)
// 0x00000091 TBuilder Google.ProtocolBuffers.AbstractBuilderLite`2::MergeFrom(Google.ProtocolBuffers.ICodedInputStream,Google.ProtocolBuffers.ExtensionRegistry)
// 0x00000092 TBuilder Google.ProtocolBuffers.AbstractBuilderLite`2::MergeFrom(Google.ProtocolBuffers.ICodedInputStream)
// 0x00000093 TBuilder Google.ProtocolBuffers.AbstractBuilderLite`2::MergeDelimitedFrom(System.IO.Stream)
// 0x00000094 TBuilder Google.ProtocolBuffers.AbstractBuilderLite`2::MergeDelimitedFrom(System.IO.Stream,Google.ProtocolBuffers.ExtensionRegistry)
// 0x00000095 TBuilder Google.ProtocolBuffers.AbstractBuilderLite`2::MergeFrom(Google.ProtocolBuffers.ByteString)
// 0x00000096 TBuilder Google.ProtocolBuffers.AbstractBuilderLite`2::MergeFrom(Google.ProtocolBuffers.ByteString,Google.ProtocolBuffers.ExtensionRegistry)
// 0x00000097 TBuilder Google.ProtocolBuffers.AbstractBuilderLite`2::MergeFrom(System.Byte[])
// 0x00000098 TBuilder Google.ProtocolBuffers.AbstractBuilderLite`2::MergeFrom(System.Byte[],Google.ProtocolBuffers.ExtensionRegistry)
// 0x00000099 TBuilder Google.ProtocolBuffers.AbstractBuilderLite`2::MergeFrom(System.IO.Stream)
// 0x0000009A TBuilder Google.ProtocolBuffers.AbstractBuilderLite`2::MergeFrom(System.IO.Stream,Google.ProtocolBuffers.ExtensionRegistry)
// 0x0000009B Google.ProtocolBuffers.IBuilderLite Google.ProtocolBuffers.AbstractBuilderLite`2::Google.ProtocolBuffers.IBuilderLite.WeakMergeFrom(Google.ProtocolBuffers.ICodedInputStream,Google.ProtocolBuffers.ExtensionRegistry)
// 0x0000009C Google.ProtocolBuffers.IMessageLite Google.ProtocolBuffers.AbstractBuilderLite`2::Google.ProtocolBuffers.IBuilderLite.WeakBuildPartial()
// 0x0000009D System.Void Google.ProtocolBuffers.AbstractBuilderLite`2::System.Runtime.Serialization.ISerializable.GetObjectData(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
// 0x0000009E System.Void Google.ProtocolBuffers.AbstractBuilderLite`2_LimitedInputStream::.ctor(System.IO.Stream,System.Int32)
// 0x0000009F System.Boolean Google.ProtocolBuffers.AbstractBuilderLite`2_LimitedInputStream::get_CanRead()
// 0x000000A0 System.Boolean Google.ProtocolBuffers.AbstractBuilderLite`2_LimitedInputStream::get_CanSeek()
// 0x000000A1 System.Boolean Google.ProtocolBuffers.AbstractBuilderLite`2_LimitedInputStream::get_CanWrite()
// 0x000000A2 System.Int64 Google.ProtocolBuffers.AbstractBuilderLite`2_LimitedInputStream::get_Length()
// 0x000000A3 System.Int64 Google.ProtocolBuffers.AbstractBuilderLite`2_LimitedInputStream::get_Position()
// 0x000000A4 System.Void Google.ProtocolBuffers.AbstractBuilderLite`2_LimitedInputStream::set_Position(System.Int64)
// 0x000000A5 System.Void Google.ProtocolBuffers.AbstractBuilderLite`2_LimitedInputStream::Flush()
// 0x000000A6 System.Int32 Google.ProtocolBuffers.AbstractBuilderLite`2_LimitedInputStream::Read(System.Byte[],System.Int32,System.Int32)
// 0x000000A7 System.Int64 Google.ProtocolBuffers.AbstractBuilderLite`2_LimitedInputStream::Seek(System.Int64,System.IO.SeekOrigin)
// 0x000000A8 System.Void Google.ProtocolBuffers.AbstractBuilderLite`2_LimitedInputStream::Write(System.Byte[],System.Int32,System.Int32)
// 0x000000A9 System.Void Google.ProtocolBuffers.AbstractBuilderLite`2_SerializationSurrogate::.ctor(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
// 0x000000AA System.Object Google.ProtocolBuffers.AbstractBuilderLite`2_SerializationSurrogate::System.Runtime.Serialization.IObjectReference.GetRealObject(System.Runtime.Serialization.StreamingContext)
// 0x000000AB System.Void Google.ProtocolBuffers.AbstractBuilderLite`2_SerializationSurrogate::System.Runtime.Serialization.ISerializable.GetObjectData(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
// 0x000000AC System.Void Google.ProtocolBuffers.AbstractBuilderLite`2_SerializationSurrogate::.cctor()
// 0x000000AD System.Void Google.ProtocolBuffers.InvalidProtocolBufferException::.ctor(System.String)
extern void InvalidProtocolBufferException__ctor_m82587930FDC7CF75A04B507E73E644DBF28BCF0E (void);
// 0x000000AE Google.ProtocolBuffers.InvalidProtocolBufferException Google.ProtocolBuffers.InvalidProtocolBufferException::TruncatedMessage()
extern void InvalidProtocolBufferException_TruncatedMessage_m0F1518DA8E834E0AA913C21046D14AE4F332A23F (void);
// 0x000000AF Google.ProtocolBuffers.InvalidProtocolBufferException Google.ProtocolBuffers.InvalidProtocolBufferException::NegativeSize()
extern void InvalidProtocolBufferException_NegativeSize_mE83794AAC7C961105F3DE44D5128635DD49D87E5 (void);
// 0x000000B0 Google.ProtocolBuffers.InvalidProtocolBufferException Google.ProtocolBuffers.InvalidProtocolBufferException::MalformedVarint()
extern void InvalidProtocolBufferException_MalformedVarint_m0756001DC26E773821E1279F93937EBE65D39634 (void);
// 0x000000B1 Google.ProtocolBuffers.InvalidProtocolBufferException Google.ProtocolBuffers.InvalidProtocolBufferException::InvalidTag()
extern void InvalidProtocolBufferException_InvalidTag_m9DBE12CAA1E271794334B86D0BA59CBD5648B1E5 (void);
// 0x000000B2 Google.ProtocolBuffers.InvalidProtocolBufferException Google.ProtocolBuffers.InvalidProtocolBufferException::InvalidEndTag()
extern void InvalidProtocolBufferException_InvalidEndTag_m44C403DCD5ABF407C892941533DEA994CA3A0988 (void);
// 0x000000B3 Google.ProtocolBuffers.InvalidProtocolBufferException Google.ProtocolBuffers.InvalidProtocolBufferException::InvalidWireType()
extern void InvalidProtocolBufferException_InvalidWireType_m51F656A8F5AE76B6CD8ED343F712CFF4255D2F3F (void);
// 0x000000B4 Google.ProtocolBuffers.InvalidProtocolBufferException Google.ProtocolBuffers.InvalidProtocolBufferException::RecursionLimitExceeded()
extern void InvalidProtocolBufferException_RecursionLimitExceeded_m4D9BE2951461ECA65434439A0E1E12C878B16735 (void);
// 0x000000B5 Google.ProtocolBuffers.InvalidProtocolBufferException Google.ProtocolBuffers.InvalidProtocolBufferException::SizeLimitExceeded()
extern void InvalidProtocolBufferException_SizeLimitExceeded_m3BEC675C6D09C08DED8EF7C8BA2FC3A015895B47 (void);
// 0x000000B6 System.Globalization.CultureInfo Google.ProtocolBuffers.FrameworkPortability::get_InvariantCulture()
extern void FrameworkPortability_get_InvariantCulture_m88D300312A84CE7D244C8C22272D988912EA1A12 (void);
// 0x000000B7 System.Void Google.ProtocolBuffers.FrameworkPortability::.cctor()
extern void FrameworkPortability__cctor_mDD51694847B6996EA1C3EA84C8B5CDE6141D65AE (void);
// 0x000000B8 System.Void Google.ProtocolBuffers.ThrowHelper::ThrowIfNull(System.Object,System.String)
extern void ThrowHelper_ThrowIfNull_m2E4DC9108B27449ACAAF01C5218B752EAD31AE59 (void);
// 0x000000B9 System.Void Google.ProtocolBuffers.ThrowHelper::ThrowIfNull(System.Object)
extern void ThrowHelper_ThrowIfNull_mB8435B4F2F4DB53E02BD873006D61C1E9D826D0A (void);
// 0x000000BA System.Void Google.ProtocolBuffers.ThrowHelper::ThrowIfAnyNull(System.Collections.Generic.IEnumerable`1<T>)
// 0x000000BB TMessage Google.ProtocolBuffers.GeneratedMessageLite`2::get_ThisMessage()
// 0x000000BC System.Void Google.ProtocolBuffers.GeneratedMessageLite`2::.ctor()
// 0x000000BD System.String Google.ProtocolBuffers.GeneratedMessageLite`2::ToString()
// 0x000000BE System.Void Google.ProtocolBuffers.GeneratedMessageLite`2::PrintField(System.String,System.Collections.Generic.IList`1<T>,System.IO.TextWriter)
// 0x000000BF System.Void Google.ProtocolBuffers.GeneratedMessageLite`2::PrintField(System.String,System.Boolean,System.Object,System.IO.TextWriter)
// 0x000000C0 System.Void Google.ProtocolBuffers.GeneratedMessageLite`2::EscapeBytes(System.Collections.Generic.IEnumerable`1<System.Byte>,System.IO.TextWriter)
// 0x000000C1 Google.ProtocolBuffers.WireFormat_WireType Google.ProtocolBuffers.WireFormat::GetTagWireType(System.UInt32)
extern void WireFormat_GetTagWireType_mC2E691E0C75357305D00F3BB6AB2783764E86B1A (void);
// 0x000000C2 System.Boolean Google.ProtocolBuffers.WireFormat::IsEndGroupTag(System.UInt32)
extern void WireFormat_IsEndGroupTag_mC38F0DEA5E885A3523C4B63DA3CC0DBB83F00B35 (void);
// 0x000000C3 System.Int32 Google.ProtocolBuffers.WireFormat::GetTagFieldNumber(System.UInt32)
extern void WireFormat_GetTagFieldNumber_m8F294B6FC91FDE36C55F136E66FB73543C537018 (void);
// 0x000000C4 System.UInt32 Google.ProtocolBuffers.WireFormat::MakeTag(System.Int32,Google.ProtocolBuffers.WireFormat_WireType)
extern void WireFormat_MakeTag_m9BF62F1578FA7B2877A8D1458026E19AAFE3964F (void);
// 0x000000C5 Google.ProtocolBuffers.IBuilderLite Google.ProtocolBuffers.IBuilderLite::WeakMergeFrom(Google.ProtocolBuffers.ICodedInputStream,Google.ProtocolBuffers.ExtensionRegistry)
// 0x000000C6 Google.ProtocolBuffers.IMessageLite Google.ProtocolBuffers.IBuilderLite::WeakBuildPartial()
// 0x000000C7 System.Void Google.ProtocolBuffers.ByteArray::Copy(System.Byte[],System.Int32,System.Byte[],System.Int32,System.Int32)
extern void ByteArray_Copy_m557A996C1B60E97D2E479EEE8D9CB321AB75B8FF (void);
// 0x000000C8 System.Void Google.ProtocolBuffers.ByteArray::ByteCopy(System.Byte[],System.Int32,System.Byte[],System.Int32,System.Int32)
extern void ByteArray_ByteCopy_m94ECDFD1389C9541A9F67272EE4EE4B3C9E4A0BB (void);
// 0x000000C9 System.Void Google.ProtocolBuffers.ByteArray::Reverse(System.Byte[])
extern void ByteArray_Reverse_m34CB3CB538881691666A11172E354C907CC19910 (void);
// 0x000000CA System.String Google.ProtocolBuffers.IEnumLite::get_Name()
// 0x000000CB System.Void Google.ProtocolBuffers.EnumParser`1::.cctor()
// 0x000000CC System.Boolean Google.ProtocolBuffers.EnumParser`1::TryConvert(System.Int32,T&)
// 0x000000CD System.Int32 Google.ProtocolBuffers.IMessageLite::get_SerializedSize()
// 0x000000CE System.Void Google.ProtocolBuffers.IMessageLite::WriteTo(Google.ProtocolBuffers.ICodedOutputStream)
// 0x000000CF System.Void Google.ProtocolBuffers.IMessageLite::PrintTo(System.IO.TextWriter)
// 0x000000D0 Google.ProtocolBuffers.IBuilderLite Google.ProtocolBuffers.IMessageLite::WeakCreateBuilderForType()
// 0x000000D1 System.Boolean Google.ProtocolBuffers.ICodedInputStream::ReadTag(System.UInt32&,System.String&)
// 0x000000D2 System.Boolean Google.ProtocolBuffers.ICodedInputStream::ReadFloat(System.Single&)
// 0x000000D3 System.Boolean Google.ProtocolBuffers.ICodedInputStream::ReadInt64(System.Int64&)
// 0x000000D4 System.Boolean Google.ProtocolBuffers.ICodedInputStream::ReadInt32(System.Int32&)
// 0x000000D5 System.Void Google.ProtocolBuffers.ICodedInputStream::ReadMessage(Google.ProtocolBuffers.IBuilderLite,Google.ProtocolBuffers.ExtensionRegistry)
// 0x000000D6 System.Boolean Google.ProtocolBuffers.ICodedInputStream::ReadEnum(T&,System.Object&)
// 0x000000D7 System.Void Google.ProtocolBuffers.ICodedInputStream::ReadMessageArray(System.UInt32,System.String,System.Collections.Generic.ICollection`1<T>,T,Google.ProtocolBuffers.ExtensionRegistry)
// 0x000000D8 System.Boolean Google.ProtocolBuffers.ICodedInputStream::SkipField()
// 0x000000D9 System.Void Google.ProtocolBuffers.ICodedInputStream::ReadFloatArray(System.UInt32,System.String,System.Collections.Generic.ICollection`1<System.Single>)
static Il2CppMethodPointer s_methodPointers[217] = 
{
	ExtensionRegistry__ctor_mF4099F865F601799805753719699B51A1F8BF699,
	ExtensionRegistry_get_Empty_mC76700E7B42667A40F8433F271510D22D330BF29,
	ExtensionRegistry_CreateInstance_mBE28073ABF59242395C31E9DFAC9B7FEA784BCB7,
	ExtensionRegistry__cctor_mD36BBA297AACB67B5478C47FD5AFF2775B3CD987,
	ExtensionIntPair_GetHashCode_m1D21D9A1D7D3E5A2ECEE9383AF118B4F3D82D299_AdjustorThunk,
	ExtensionIntPair_Equals_m224294E7F9245BCED0B0DD828A59F136212F97C4_AdjustorThunk,
	ExtensionIntPair_Equals_m8276EEC0E6636D5526116D44148196AAC89AADB2_AdjustorThunk,
	CodedInputStream__ctor_m25002ECFA7626046D8621E40717D71243CDBE91E,
	CodedInputStream__ctor_m60B9F9B76FAA08808B1243A383E5E2CCCAFFC9F6,
	CodedInputStream_get_ReachedLimit_m8736B51914163DE2A8837C2288A079F06C86FB64,
	CodedInputStream_get_IsAtEnd_m8417EC83EC7CE827735CE42EFF467BDAC85D567E,
	CodedInputStream_CreateInstance_mED0E557FA356ADBC18ED093E2D7BF13840CF0E44,
	CodedInputStream_CreateInstance_mDCCBF7B8F327F1FDD334431F754FEF73841F3D85,
	CodedInputStream_CheckLastTagWas_m0DAA172667D4075A6914716396E1CDFF96CAF5A3,
	CodedInputStream_PeekNextTag_m2D28A65E348CF9D6E884D6A4428B385D3B88568F,
	CodedInputStream_ReadTag_m23AD3CE9C1EA9C2A60CDF47055EFD90C8478A9F4,
	CodedInputStream_ReadFloat_mD9086AA478EBB9116119E886132EB77A34057BF7,
	CodedInputStream_ReadInt64_m55FA77E4A4E9CECBEE875A15D592E2310FA3989C,
	CodedInputStream_ReadInt32_m5DFAF195BE1D9460F1054F33F7546C03C5C4BFE4,
	CodedInputStream_ReadMessage_m7DA8CB99856FBF06EB24656EF1C0634F1FDC2BA5,
	NULL,
	CodedInputStream_BeginArray_m42A2EF56555A3ACE3DE02F1E55991703473174B3,
	CodedInputStream_ContinueArray_m9E5201C6D13EB4E669B86309DBD08AB6C3AE8C0A,
	CodedInputStream_ContinueArray_m89C18ABC3064B5E3173D09BFA8FC6263A670B639,
	CodedInputStream_ReadFloatArray_mF36250455461A4B25D959E30D16B13AF600E384A,
	NULL,
	CodedInputStream_SlowReadRawVarint32_m4BD0F8ACC2A9B6335AB0B17D19AFE65109DD63DC,
	CodedInputStream_ReadRawVarint32_m3D50095F615E35805EE5EFF1A95111BEE84A0F83,
	CodedInputStream_ReadRawVarint32_mEB99186B7A2BBACABCAEFB4579EBA9BB1DBA1265,
	CodedInputStream_ReadRawVarint64_mDD7099D0590839AFA896E033EECD43E82B834071,
	CodedInputStream_ReadRawLittleEndian32_m701343A2D5D3D8BBB543E45C171B1251BFD55658,
	CodedInputStream_ReadRawLittleEndian64_m0DC389BC213758ED97481456E282ED2CF0000E42,
	CodedInputStream_PushLimit_m055A0982177C87205DA4AB870A4C0CF56AFE9C7E,
	CodedInputStream_RecomputeBufferSizeAfterLimit_m9C20EE52E2D94F82A602FA3EF3DA5CB87E0A2EE7,
	CodedInputStream_PopLimit_m194E43997E0D1E8EF3C6F6A67C7350F60AD92465,
	CodedInputStream_RefillBuffer_mAFD4A09A9127023CB6024245B27394DC234C242F,
	CodedInputStream_ReadRawByte_m511DFAE58BB34C5CEC4487BEFDD2EB72016E7F70,
	CodedInputStream_ReadRawBytes_m60E3439632092B8C7EE2D22682B7F7DC672184CA,
	CodedInputStream_SkipField_m8D83720F0C50B636EAA76C82C9993FABF8EBF907,
	CodedInputStream_SkipMessage_mB6E7938C82845EA0474DCCC8122DD5BE8C634DF0,
	CodedInputStream_SkipRawBytes_m8EC3B6FCCE8F72B0DA9DE76DDCE8964904676108,
	CodedInputStream_SkipImpl_m4CBC750F18077F37088AF8F8A28E664AB323DF88,
	ByteString__ctor_m77972159D66DA7ECFBD8E7B620B65D85B9ACD041,
	ByteString_GetEnumerator_mBC3C445EB21B657575B4BA250D0B3816561A4249,
	ByteString_System_Collections_IEnumerable_GetEnumerator_m34F2DA34980CB755B3D7B2CBE72FA16ED0B48EBF,
	ByteString_CreateCodedInput_m82BF44BB2E98BE75D8ED0BFBE1373293745309B1,
	ByteString_Equals_m4DA87E7B49C2CEA07E21ACA2322430222A9C3163,
	ByteString_GetHashCode_m268B011825773C6512A8370AA00979838849D63C,
	ByteString_Equals_mEFC46C0676208219A7AEF437AF30BC0160B87BA8,
	ByteString__cctor_mB4E455AD3CC78C9C46FADB102DE08F78400AEEEF,
	UninitializedMessageException__ctor_m90F992B8FE15D9561ED07370C274A52EC43736BB,
	UninitializedMessageException_AsInvalidProtocolBufferException_m9731AF29AD15EF96286EC9A80AC4B2DF39C534A7,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	CodedOutputStream__ctor_m5440A4DAF33751466097FD4CD85D7A7562BDA564,
	CodedOutputStream_get_SpaceLeft_mADAF9D8D680791DD50C0ED974809FA602BD2BB8C,
	CodedOutputStream_ComputeFloatSize_m590AFD0BAD36720168DBFB2EA91754E846F70BC7,
	CodedOutputStream_ComputeInt64Size_m469FA3555088F5F6436873B0B862B27DAC90A566,
	CodedOutputStream_ComputeInt32Size_m81AD208FD9D9AA6BEF44E7DED4F46FA8D6E3390B,
	CodedOutputStream_ComputeMessageSize_m8EB8C8EA0C467313A246817B90D1AD63BC4011C9,
	CodedOutputStream_ComputeEnumSize_mE1251105EDCED82ABE3F9E4E3AA12EBD71949655,
	CodedOutputStream_ComputeInt32SizeNoTag_m370909614401731E07D4DEACEF7488A38A30B01C,
	CodedOutputStream_ComputeEnumSizeNoTag_mCB5B90A0B231A5802F44CFC5ADAEB1242F0553C5,
	CodedOutputStream_ComputeRawVarint32Size_mBB34A0D2142D18730820495009D674EB2F889E32,
	CodedOutputStream_ComputeRawVarint64Size_mA787C8FE03DED2971D70313ABC7B71F37F466B82,
	CodedOutputStream_ComputeTagSize_mE2C32E82317507B0C0E344AC0D218A8F6EA12CBE,
	CodedOutputStream_CreateInstance_m54CE3BE9AEF110DA1EA545A191E591367E7CA9A6,
	CodedOutputStream_CreateInstance_mB40511EA02D789AE51561B3B3A2A0F7A54CC1DD5,
	CodedOutputStream_WriteFloat_m3EEF3CB5A52127C6DBE9585F99CDF58B4A7D8DD8,
	CodedOutputStream_WriteInt64_m019539F5E16160623E854D43D7B236ECA542AE0F,
	CodedOutputStream_WriteInt32_m882E713613E8F5F75C53B0788BBE02DD6799B6CA,
	CodedOutputStream_WriteMessage_m0D6B8F598C7EF8006829246B5894C874C4AA96FC,
	CodedOutputStream_WriteEnum_mB1B7A037BEC4C5488B23CE12848D52AE87D012A2,
	CodedOutputStream_WriteFloatNoTag_m237A87522C5A2E3AF41EB69F7B0DF415F7A87B95,
	CodedOutputStream_WriteInt32NoTag_m44A3C8BF676D904191FEA4C1C744449631AE4EA8,
	NULL,
	CodedOutputStream_WritePackedFloatArray_m831FBF27B71E42F6BF8949A3656ADF54E5201301,
	CodedOutputStream_WriteTag_mAD0902B5FFE753EFD6C311DDFB11C77703DE9F31,
	CodedOutputStream_WriteRawVarint32_m600FA15E7AE0A175329E1213BD91F4D27B8F43E7,
	CodedOutputStream_WriteRawVarint64_mEB769FF529708B0B04BAA1FCC5843351E255F681,
	CodedOutputStream_WriteRawByte_m2E7A872FBE5B33184F0106F8797920B7A17A6AA6,
	CodedOutputStream_WriteRawBytes_mC6EF30495677ECD22E0F6055388DD33D7592B2B0,
	CodedOutputStream_RefreshBuffer_m228716090B0D4D7716E2FA4E1EBFCE4061F65B0A,
	CodedOutputStream_CheckNoSpaceLeft_mC23977D42A81BA5E37063FD8117EC568D90B466B,
	CodedOutputStream__cctor_m04BA84AE430F59CB6222197FBEA2E27AD0099507,
	OutOfSpaceException__ctor_m5B2FF11494FCA787A208E50C60B5D250C87B9249,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	InvalidProtocolBufferException__ctor_m82587930FDC7CF75A04B507E73E644DBF28BCF0E,
	InvalidProtocolBufferException_TruncatedMessage_m0F1518DA8E834E0AA913C21046D14AE4F332A23F,
	InvalidProtocolBufferException_NegativeSize_mE83794AAC7C961105F3DE44D5128635DD49D87E5,
	InvalidProtocolBufferException_MalformedVarint_m0756001DC26E773821E1279F93937EBE65D39634,
	InvalidProtocolBufferException_InvalidTag_m9DBE12CAA1E271794334B86D0BA59CBD5648B1E5,
	InvalidProtocolBufferException_InvalidEndTag_m44C403DCD5ABF407C892941533DEA994CA3A0988,
	InvalidProtocolBufferException_InvalidWireType_m51F656A8F5AE76B6CD8ED343F712CFF4255D2F3F,
	InvalidProtocolBufferException_RecursionLimitExceeded_m4D9BE2951461ECA65434439A0E1E12C878B16735,
	InvalidProtocolBufferException_SizeLimitExceeded_m3BEC675C6D09C08DED8EF7C8BA2FC3A015895B47,
	FrameworkPortability_get_InvariantCulture_m88D300312A84CE7D244C8C22272D988912EA1A12,
	FrameworkPortability__cctor_mDD51694847B6996EA1C3EA84C8B5CDE6141D65AE,
	ThrowHelper_ThrowIfNull_m2E4DC9108B27449ACAAF01C5218B752EAD31AE59,
	ThrowHelper_ThrowIfNull_mB8435B4F2F4DB53E02BD873006D61C1E9D826D0A,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	WireFormat_GetTagWireType_mC2E691E0C75357305D00F3BB6AB2783764E86B1A,
	WireFormat_IsEndGroupTag_mC38F0DEA5E885A3523C4B63DA3CC0DBB83F00B35,
	WireFormat_GetTagFieldNumber_m8F294B6FC91FDE36C55F136E66FB73543C537018,
	WireFormat_MakeTag_m9BF62F1578FA7B2877A8D1458026E19AAFE3964F,
	NULL,
	NULL,
	ByteArray_Copy_m557A996C1B60E97D2E479EEE8D9CB321AB75B8FF,
	ByteArray_ByteCopy_m94ECDFD1389C9541A9F67272EE4EE4B3C9E4A0BB,
	ByteArray_Reverse_m34CB3CB538881691666A11172E354C907CC19910,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
};
static const int32_t s_InvokerIndices[217] = 
{
	98,
	4,
	4,
	3,
	10,
	9,
	1346,
	35,
	26,
	102,
	102,
	0,
	0,
	32,
	759,
	759,
	758,
	758,
	758,
	27,
	-1,
	1347,
	30,
	1348,
	347,
	-1,
	10,
	10,
	186,
	130,
	10,
	130,
	37,
	23,
	32,
	176,
	102,
	34,
	102,
	23,
	32,
	32,
	26,
	14,
	14,
	14,
	9,
	10,
	9,
	3,
	26,
	14,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	1349,
	1350,
	713,
	347,
	1351,
	-1,
	1351,
	35,
	10,
	1352,
	1353,
	125,
	1354,
	125,
	21,
	21,
	21,
	217,
	21,
	0,
	151,
	1349,
	1350,
	713,
	347,
	1351,
	275,
	32,
	-1,
	1351,
	157,
	32,
	160,
	31,
	35,
	23,
	23,
	3,
	23,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	26,
	4,
	4,
	4,
	4,
	4,
	4,
	4,
	4,
	4,
	3,
	122,
	111,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	21,
	46,
	21,
	125,
	101,
	14,
	155,
	155,
	111,
	14,
	-1,
	-1,
	10,
	26,
	26,
	14,
	759,
	758,
	758,
	758,
	27,
	-1,
	-1,
	102,
	347,
};
static const Il2CppTokenRangePair s_rgctxIndices[15] = 
{
	{ 0x02000007, { 4, 7 } },
	{ 0x0200000B, { 14, 7 } },
	{ 0x0200000C, { 21, 9 } },
	{ 0x0200000D, { 30, 24 } },
	{ 0x0200000F, { 56, 5 } },
	{ 0x02000012, { 61, 14 } },
	{ 0x02000014, { 75, 7 } },
	{ 0x02000018, { 85, 6 } },
	{ 0x0200001E, { 94, 11 } },
	{ 0x06000015, { 0, 2 } },
	{ 0x0600001A, { 2, 2 } },
	{ 0x06000058, { 11, 3 } },
	{ 0x06000085, { 54, 2 } },
	{ 0x060000BA, { 82, 3 } },
	{ 0x060000BE, { 91, 3 } },
};
static const Il2CppRGCTXDefinition s_rgctxValues[105] = 
{
	{ (Il2CppRGCTXDataType)3, 7493 },
	{ (Il2CppRGCTXDataType)2, 13656 },
	{ (Il2CppRGCTXDataType)2, 11697 },
	{ (Il2CppRGCTXDataType)2, 11696 },
	{ (Il2CppRGCTXDataType)3, 7494 },
	{ (Il2CppRGCTXDataType)2, 11709 },
	{ (Il2CppRGCTXDataType)3, 7495 },
	{ (Il2CppRGCTXDataType)3, 7496 },
	{ (Il2CppRGCTXDataType)3, 7497 },
	{ (Il2CppRGCTXDataType)2, 11710 },
	{ (Il2CppRGCTXDataType)3, 7498 },
	{ (Il2CppRGCTXDataType)2, 11720 },
	{ (Il2CppRGCTXDataType)2, 13657 },
	{ (Il2CppRGCTXDataType)2, 11721 },
	{ (Il2CppRGCTXDataType)3, 7499 },
	{ (Il2CppRGCTXDataType)3, 7500 },
	{ (Il2CppRGCTXDataType)3, 7501 },
	{ (Il2CppRGCTXDataType)2, 11728 },
	{ (Il2CppRGCTXDataType)1, 13658 },
	{ (Il2CppRGCTXDataType)3, 7502 },
	{ (Il2CppRGCTXDataType)3, 7503 },
	{ (Il2CppRGCTXDataType)2, 13659 },
	{ (Il2CppRGCTXDataType)2, 11734 },
	{ (Il2CppRGCTXDataType)3, 7504 },
	{ (Il2CppRGCTXDataType)2, 11733 },
	{ (Il2CppRGCTXDataType)3, 7505 },
	{ (Il2CppRGCTXDataType)3, 7506 },
	{ (Il2CppRGCTXDataType)3, 7507 },
	{ (Il2CppRGCTXDataType)3, 7508 },
	{ (Il2CppRGCTXDataType)1, 11734 },
	{ (Il2CppRGCTXDataType)3, 7509 },
	{ (Il2CppRGCTXDataType)3, 7510 },
	{ (Il2CppRGCTXDataType)2, 13660 },
	{ (Il2CppRGCTXDataType)2, 11741 },
	{ (Il2CppRGCTXDataType)3, 7511 },
	{ (Il2CppRGCTXDataType)3, 7512 },
	{ (Il2CppRGCTXDataType)3, 7513 },
	{ (Il2CppRGCTXDataType)3, 7514 },
	{ (Il2CppRGCTXDataType)3, 7515 },
	{ (Il2CppRGCTXDataType)3, 7516 },
	{ (Il2CppRGCTXDataType)3, 7517 },
	{ (Il2CppRGCTXDataType)3, 7518 },
	{ (Il2CppRGCTXDataType)3, 7519 },
	{ (Il2CppRGCTXDataType)3, 7520 },
	{ (Il2CppRGCTXDataType)2, 11744 },
	{ (Il2CppRGCTXDataType)3, 7521 },
	{ (Il2CppRGCTXDataType)2, 13660 },
	{ (Il2CppRGCTXDataType)3, 7522 },
	{ (Il2CppRGCTXDataType)2, 13555 },
	{ (Il2CppRGCTXDataType)3, 7523 },
	{ (Il2CppRGCTXDataType)2, 11743 },
	{ (Il2CppRGCTXDataType)2, 13661 },
	{ (Il2CppRGCTXDataType)3, 7524 },
	{ (Il2CppRGCTXDataType)2, 11742 },
	{ (Il2CppRGCTXDataType)3, 7525 },
	{ (Il2CppRGCTXDataType)2, 13662 },
	{ (Il2CppRGCTXDataType)2, 13663 },
	{ (Il2CppRGCTXDataType)2, 13664 },
	{ (Il2CppRGCTXDataType)3, 7526 },
	{ (Il2CppRGCTXDataType)2, 13665 },
	{ (Il2CppRGCTXDataType)2, 13666 },
	{ (Il2CppRGCTXDataType)3, 7527 },
	{ (Il2CppRGCTXDataType)3, 7528 },
	{ (Il2CppRGCTXDataType)2, 13667 },
	{ (Il2CppRGCTXDataType)3, 7529 },
	{ (Il2CppRGCTXDataType)3, 7530 },
	{ (Il2CppRGCTXDataType)3, 7531 },
	{ (Il2CppRGCTXDataType)3, 7532 },
	{ (Il2CppRGCTXDataType)3, 7533 },
	{ (Il2CppRGCTXDataType)2, 11770 },
	{ (Il2CppRGCTXDataType)3, 7534 },
	{ (Il2CppRGCTXDataType)2, 11771 },
	{ (Il2CppRGCTXDataType)1, 13668 },
	{ (Il2CppRGCTXDataType)3, 7535 },
	{ (Il2CppRGCTXDataType)3, 7536 },
	{ (Il2CppRGCTXDataType)2, 13669 },
	{ (Il2CppRGCTXDataType)2, 11783 },
	{ (Il2CppRGCTXDataType)3, 7537 },
	{ (Il2CppRGCTXDataType)2, 11782 },
	{ (Il2CppRGCTXDataType)3, 7538 },
	{ (Il2CppRGCTXDataType)3, 7539 },
	{ (Il2CppRGCTXDataType)1, 11783 },
	{ (Il2CppRGCTXDataType)2, 11793 },
	{ (Il2CppRGCTXDataType)2, 13670 },
	{ (Il2CppRGCTXDataType)2, 11794 },
	{ (Il2CppRGCTXDataType)3, 7540 },
	{ (Il2CppRGCTXDataType)2, 11797 },
	{ (Il2CppRGCTXDataType)3, 6997 },
	{ (Il2CppRGCTXDataType)3, 7541 },
	{ (Il2CppRGCTXDataType)2, 11802 },
	{ (Il2CppRGCTXDataType)3, 7542 },
	{ (Il2CppRGCTXDataType)2, 13671 },
	{ (Il2CppRGCTXDataType)2, 13672 },
	{ (Il2CppRGCTXDataType)2, 11801 },
	{ (Il2CppRGCTXDataType)2, 13673 },
	{ (Il2CppRGCTXDataType)3, 7543 },
	{ (Il2CppRGCTXDataType)1, 11816 },
	{ (Il2CppRGCTXDataType)2, 11816 },
	{ (Il2CppRGCTXDataType)3, 7544 },
	{ (Il2CppRGCTXDataType)3, 7545 },
	{ (Il2CppRGCTXDataType)2, 13674 },
	{ (Il2CppRGCTXDataType)2, 13675 },
	{ (Il2CppRGCTXDataType)3, 7546 },
	{ (Il2CppRGCTXDataType)3, 7547 },
	{ (Il2CppRGCTXDataType)3, 7548 },
};
extern const Il2CppCodeGenModule g_Google_ProtocolBuffersCodeGenModule;
const Il2CppCodeGenModule g_Google_ProtocolBuffersCodeGenModule = 
{
	"Google.ProtocolBuffers.dll",
	217,
	s_methodPointers,
	s_InvokerIndices,
	0,
	NULL,
	15,
	s_rgctxIndices,
	105,
	s_rgctxValues,
	NULL,
};
