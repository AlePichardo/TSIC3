﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif



#include "codegen/il2cpp-codegen-metadata.h"





IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END




// 0x00000001 System.String UnityEngine.XR.Management.XRConfigurationDataAttribute::get_displayName()
extern void XRConfigurationDataAttribute_get_displayName_mE45F942211DF376D4E87F91CD2520C6CD4A11205 (void);
// 0x00000002 System.Void UnityEngine.XR.Management.XRConfigurationDataAttribute::set_displayName(System.String)
extern void XRConfigurationDataAttribute_set_displayName_mFD1F77DA8ACBF2A1C933F68D101A430F79F73F0D (void);
// 0x00000003 System.String UnityEngine.XR.Management.XRConfigurationDataAttribute::get_buildSettingsKey()
extern void XRConfigurationDataAttribute_get_buildSettingsKey_m86940940D99DAA49F02131A4730DC9D76B56A202 (void);
// 0x00000004 System.Void UnityEngine.XR.Management.XRConfigurationDataAttribute::set_buildSettingsKey(System.String)
extern void XRConfigurationDataAttribute_set_buildSettingsKey_m8FF1337A75491A425D570FB119C64B45E61AFCAA (void);
// 0x00000005 System.Void UnityEngine.XR.Management.XRConfigurationDataAttribute::.ctor()
extern void XRConfigurationDataAttribute__ctor_mD3C7787EE44BFB9828AEDABAF2898463F65892CB (void);
// 0x00000006 System.Void UnityEngine.XR.Management.XRConfigurationDataAttribute::.ctor(System.String,System.String)
extern void XRConfigurationDataAttribute__ctor_mB16051A05F36491CC91D3266A6F2719B9044082D (void);
// 0x00000007 UnityEngine.XR.Management.XRManagerSettings UnityEngine.XR.Management.XRGeneralSettings::get_Manager()
extern void XRGeneralSettings_get_Manager_mBD0D772CE77641DA8B7226D1A9CD3F8E699F7779 (void);
// 0x00000008 System.Void UnityEngine.XR.Management.XRGeneralSettings::set_Manager(UnityEngine.XR.Management.XRManagerSettings)
extern void XRGeneralSettings_set_Manager_mA00141C36332EE942A8FB3000E021F10B9751DBB (void);
// 0x00000009 UnityEngine.XR.Management.XRGeneralSettings UnityEngine.XR.Management.XRGeneralSettings::get_Instance()
extern void XRGeneralSettings_get_Instance_m0D915EB6CD760E30475C5F67090DD8442196FE47 (void);
// 0x0000000A UnityEngine.XR.Management.XRManagerSettings UnityEngine.XR.Management.XRGeneralSettings::get_AssignedSettings()
extern void XRGeneralSettings_get_AssignedSettings_m78AFF6E40149AE2FE4F89E55D1FABCFF3A768AF6 (void);
// 0x0000000B System.Boolean UnityEngine.XR.Management.XRGeneralSettings::get_InitManagerOnStart()
extern void XRGeneralSettings_get_InitManagerOnStart_m0CA51D67FC8AB767C45954CF09E4E152E32BB92F (void);
// 0x0000000C System.Void UnityEngine.XR.Management.XRGeneralSettings::Awake()
extern void XRGeneralSettings_Awake_m70E1426BA7E91710C8A7B82824E4377E47EF9C41 (void);
// 0x0000000D System.Void UnityEngine.XR.Management.XRGeneralSettings::Quit()
extern void XRGeneralSettings_Quit_mD6E708EB9FA9A52EDAF992CD04089A5E23522C60 (void);
// 0x0000000E System.Void UnityEngine.XR.Management.XRGeneralSettings::Start()
extern void XRGeneralSettings_Start_m3236D327A4A3E66527CEBDA2F5BDD07D01B71EA5 (void);
// 0x0000000F System.Void UnityEngine.XR.Management.XRGeneralSettings::OnDestroy()
extern void XRGeneralSettings_OnDestroy_mF1FAFD114FDDAF476767A2EDA9171942E4DCF17E (void);
// 0x00000010 System.Void UnityEngine.XR.Management.XRGeneralSettings::AttemptInitializeXRSDKOnLoad()
extern void XRGeneralSettings_AttemptInitializeXRSDKOnLoad_mC7F0EFAC852684103350BC26B573F1E085707EAD (void);
// 0x00000011 System.Void UnityEngine.XR.Management.XRGeneralSettings::AttemptStartXRSDKOnBeforeSplashScreen()
extern void XRGeneralSettings_AttemptStartXRSDKOnBeforeSplashScreen_m4D982B772260F4FFB51456402EA7DD993181FBCD (void);
// 0x00000012 System.Void UnityEngine.XR.Management.XRGeneralSettings::InitXRSDK()
extern void XRGeneralSettings_InitXRSDK_m7E948591C80EC7A2A97417A959BEA5DF4BACB58D (void);
// 0x00000013 System.Void UnityEngine.XR.Management.XRGeneralSettings::StartXRSDK()
extern void XRGeneralSettings_StartXRSDK_mE58ED248C7E672773A4D9FF8BBECEC0DBE2D0059 (void);
// 0x00000014 System.Void UnityEngine.XR.Management.XRGeneralSettings::StopXRSDK()
extern void XRGeneralSettings_StopXRSDK_m0307D54FDB9513DD49B5523D7FEC72513DE7E47F (void);
// 0x00000015 System.Void UnityEngine.XR.Management.XRGeneralSettings::DeInitXRSDK()
extern void XRGeneralSettings_DeInitXRSDK_m736781E104A1DBBFFE393393B0ADFBCB9F164EED (void);
// 0x00000016 System.Void UnityEngine.XR.Management.XRGeneralSettings::.ctor()
extern void XRGeneralSettings__ctor_mF398EFC4AD993C540516487FC50F83C2468DFB3A (void);
// 0x00000017 System.Void UnityEngine.XR.Management.XRGeneralSettings::.cctor()
extern void XRGeneralSettings__cctor_m3894F3807749E1AA75D5D4995DD41CB3DCE5C44D (void);
// 0x00000018 System.Boolean UnityEngine.XR.Management.XRLoader::Initialize()
extern void XRLoader_Initialize_m5E528D0A51C1AD2732689F548B99E1A88470BD02 (void);
// 0x00000019 System.Boolean UnityEngine.XR.Management.XRLoader::Start()
extern void XRLoader_Start_mBA33843711A6DFB08AC623A2F2892FD71CB1DDE7 (void);
// 0x0000001A System.Boolean UnityEngine.XR.Management.XRLoader::Stop()
extern void XRLoader_Stop_m2E7F152C1FAF60294D7A95E077719AF493869894 (void);
// 0x0000001B System.Boolean UnityEngine.XR.Management.XRLoader::Deinitialize()
extern void XRLoader_Deinitialize_m863CE4A82FE431245E25BA85C04DC3F0E8E88CDA (void);
// 0x0000001C T UnityEngine.XR.Management.XRLoader::GetLoadedSubsystem()
// 0x0000001D System.Collections.Generic.List`1<UnityEngine.Rendering.GraphicsDeviceType> UnityEngine.XR.Management.XRLoader::GetSupportedGraphicsDeviceTypes(System.Boolean)
extern void XRLoader_GetSupportedGraphicsDeviceTypes_m322533865DF60C4FD1F029988C4C4AEF1925FD5E (void);
// 0x0000001E System.Void UnityEngine.XR.Management.XRLoader::.ctor()
extern void XRLoader__ctor_m9F3AB0D960DC1395FBBF3D0D65EB27E70662B4B8 (void);
// 0x0000001F T UnityEngine.XR.Management.XRLoaderHelper::GetLoadedSubsystem()
// 0x00000020 System.Void UnityEngine.XR.Management.XRLoaderHelper::StartSubsystem()
// 0x00000021 System.Void UnityEngine.XR.Management.XRLoaderHelper::StopSubsystem()
// 0x00000022 System.Void UnityEngine.XR.Management.XRLoaderHelper::DestroySubsystem()
// 0x00000023 System.Void UnityEngine.XR.Management.XRLoaderHelper::CreateSubsystem(System.Collections.Generic.List`1<TDescriptor>,System.String)
// 0x00000024 System.Void UnityEngine.XR.Management.XRLoaderHelper::CreateIntegratedSubsystem(System.Collections.Generic.List`1<TDescriptor>,System.String)
// 0x00000025 System.Void UnityEngine.XR.Management.XRLoaderHelper::CreateStandaloneSubsystem(System.Collections.Generic.List`1<TDescriptor>,System.String)
// 0x00000026 System.Boolean UnityEngine.XR.Management.XRLoaderHelper::Deinitialize()
extern void XRLoaderHelper_Deinitialize_m46197AF56BC868F789B95FD1702F58BB4265A376 (void);
// 0x00000027 System.Void UnityEngine.XR.Management.XRLoaderHelper::.ctor()
extern void XRLoaderHelper__ctor_m61180EE7C9A2091D2120E4FCBA1A022333248FD6 (void);
// 0x00000028 System.Boolean UnityEngine.XR.Management.XRManagerSettings::get_automaticLoading()
extern void XRManagerSettings_get_automaticLoading_mDCB2A7289C4FE8BD7FBA7CA207CE4EEE14C19CA9 (void);
// 0x00000029 System.Void UnityEngine.XR.Management.XRManagerSettings::set_automaticLoading(System.Boolean)
extern void XRManagerSettings_set_automaticLoading_mF7787829863EF4D75DC56716E9283C9D456030DD (void);
// 0x0000002A System.Boolean UnityEngine.XR.Management.XRManagerSettings::get_automaticRunning()
extern void XRManagerSettings_get_automaticRunning_mDC0FE3222A77630AB1D51AA0811CCA3132024C59 (void);
// 0x0000002B System.Void UnityEngine.XR.Management.XRManagerSettings::set_automaticRunning(System.Boolean)
extern void XRManagerSettings_set_automaticRunning_m0B46221356F33FFE168DACAA8812E938036FD439 (void);
// 0x0000002C System.Collections.Generic.List`1<UnityEngine.XR.Management.XRLoader> UnityEngine.XR.Management.XRManagerSettings::get_loaders()
extern void XRManagerSettings_get_loaders_mBD4F29A6F89D5D620634FC1853A88257FA58AE36 (void);
// 0x0000002D System.Boolean UnityEngine.XR.Management.XRManagerSettings::get_isInitializationComplete()
extern void XRManagerSettings_get_isInitializationComplete_m878C7DDB712D4F99160B2F7C71CBFC201F5AB63F (void);
// 0x0000002E UnityEngine.XR.Management.XRLoader UnityEngine.XR.Management.XRManagerSettings::get_activeLoader()
extern void XRManagerSettings_get_activeLoader_m9371C31D367F55202EE948306D0C61A9D8725B67 (void);
// 0x0000002F System.Void UnityEngine.XR.Management.XRManagerSettings::set_activeLoader(UnityEngine.XR.Management.XRLoader)
extern void XRManagerSettings_set_activeLoader_m4961B290666B1461944FD0487DECB699A903D8D3 (void);
// 0x00000030 T UnityEngine.XR.Management.XRManagerSettings::ActiveLoaderAs()
// 0x00000031 System.Void UnityEngine.XR.Management.XRManagerSettings::InitializeLoaderSync()
extern void XRManagerSettings_InitializeLoaderSync_mC8931AA78045796B6C9CFCF8CAF6FB0B54C40025 (void);
// 0x00000032 System.Collections.IEnumerator UnityEngine.XR.Management.XRManagerSettings::InitializeLoader()
extern void XRManagerSettings_InitializeLoader_m6AE56C59F2EDD415911272B417E0085F6009667F (void);
// 0x00000033 System.Boolean UnityEngine.XR.Management.XRManagerSettings::CheckGraphicsAPICompatibility(UnityEngine.XR.Management.XRLoader)
extern void XRManagerSettings_CheckGraphicsAPICompatibility_m17471A8679FF7F6CD90FFB12D036A5075DF3F8C1 (void);
// 0x00000034 System.Void UnityEngine.XR.Management.XRManagerSettings::StartSubsystems()
extern void XRManagerSettings_StartSubsystems_m3A10751468041448DBCB179136F3313FEA29537F (void);
// 0x00000035 System.Void UnityEngine.XR.Management.XRManagerSettings::StopSubsystems()
extern void XRManagerSettings_StopSubsystems_m1B4A77F81B323A476A1446FF1AD1B3F2482FB7A9 (void);
// 0x00000036 System.Void UnityEngine.XR.Management.XRManagerSettings::DeinitializeLoader()
extern void XRManagerSettings_DeinitializeLoader_mAEB6EFBBDB20076FC3B7DB17D7B2FAA34E2C5E2C (void);
// 0x00000037 System.Void UnityEngine.XR.Management.XRManagerSettings::Start()
extern void XRManagerSettings_Start_m318DCEC189E13498E539AD0FD1411F006ADFC987 (void);
// 0x00000038 System.Void UnityEngine.XR.Management.XRManagerSettings::OnDisable()
extern void XRManagerSettings_OnDisable_mBF327F3EF9A66EE05ABFFF207440B683CBC9A25E (void);
// 0x00000039 System.Void UnityEngine.XR.Management.XRManagerSettings::OnDestroy()
extern void XRManagerSettings_OnDestroy_m0D6707A5F61284A0BB3808ABBEB8EEA82C92452A (void);
// 0x0000003A System.Void UnityEngine.XR.Management.XRManagerSettings::.ctor()
extern void XRManagerSettings__ctor_mC1B877CD102E57833EE8D4811A9424598F34078B (void);
// 0x0000003B System.Void UnityEngine.XR.Management.XRManagerSettings::.cctor()
extern void XRManagerSettings__cctor_m6AEE40CBB054335113BCA1BE4C4DAA4DFCD4BF99 (void);
// 0x0000003C System.Void UnityEngine.XR.Management.XRManagerSettings_<InitializeLoader>d__21::.ctor(System.Int32)
extern void U3CInitializeLoaderU3Ed__21__ctor_mE1EFD8B0AE006E71FC3596E10AB1BFAC6B7570E1 (void);
// 0x0000003D System.Void UnityEngine.XR.Management.XRManagerSettings_<InitializeLoader>d__21::System.IDisposable.Dispose()
extern void U3CInitializeLoaderU3Ed__21_System_IDisposable_Dispose_m3D0F83E1A23AF0F08427EF6C1FC7FBB8BCA5FE4D (void);
// 0x0000003E System.Boolean UnityEngine.XR.Management.XRManagerSettings_<InitializeLoader>d__21::MoveNext()
extern void U3CInitializeLoaderU3Ed__21_MoveNext_mC17EDB30580E987D970F6F6AB785210EF7FE5AA2 (void);
// 0x0000003F System.Void UnityEngine.XR.Management.XRManagerSettings_<InitializeLoader>d__21::<>m__Finally1()
extern void U3CInitializeLoaderU3Ed__21_U3CU3Em__Finally1_m8B409C7A2D9E4222422F06BFEC8DF4D3F1187747 (void);
// 0x00000040 System.Object UnityEngine.XR.Management.XRManagerSettings_<InitializeLoader>d__21::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CInitializeLoaderU3Ed__21_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mBC84CBAC26C6E31E3B7368934B5DE21A94FE484B (void);
// 0x00000041 System.Void UnityEngine.XR.Management.XRManagerSettings_<InitializeLoader>d__21::System.Collections.IEnumerator.Reset()
extern void U3CInitializeLoaderU3Ed__21_System_Collections_IEnumerator_Reset_mA8F74EB916C42DF0855C5110619D38843142C4E4 (void);
// 0x00000042 System.Object UnityEngine.XR.Management.XRManagerSettings_<InitializeLoader>d__21::System.Collections.IEnumerator.get_Current()
extern void U3CInitializeLoaderU3Ed__21_System_Collections_IEnumerator_get_Current_m6332A8667B15EA740D7E8F292B2F324594C31F60 (void);
static Il2CppMethodPointer s_methodPointers[66] = 
{
	XRConfigurationDataAttribute_get_displayName_mE45F942211DF376D4E87F91CD2520C6CD4A11205,
	XRConfigurationDataAttribute_set_displayName_mFD1F77DA8ACBF2A1C933F68D101A430F79F73F0D,
	XRConfigurationDataAttribute_get_buildSettingsKey_m86940940D99DAA49F02131A4730DC9D76B56A202,
	XRConfigurationDataAttribute_set_buildSettingsKey_m8FF1337A75491A425D570FB119C64B45E61AFCAA,
	XRConfigurationDataAttribute__ctor_mD3C7787EE44BFB9828AEDABAF2898463F65892CB,
	XRConfigurationDataAttribute__ctor_mB16051A05F36491CC91D3266A6F2719B9044082D,
	XRGeneralSettings_get_Manager_mBD0D772CE77641DA8B7226D1A9CD3F8E699F7779,
	XRGeneralSettings_set_Manager_mA00141C36332EE942A8FB3000E021F10B9751DBB,
	XRGeneralSettings_get_Instance_m0D915EB6CD760E30475C5F67090DD8442196FE47,
	XRGeneralSettings_get_AssignedSettings_m78AFF6E40149AE2FE4F89E55D1FABCFF3A768AF6,
	XRGeneralSettings_get_InitManagerOnStart_m0CA51D67FC8AB767C45954CF09E4E152E32BB92F,
	XRGeneralSettings_Awake_m70E1426BA7E91710C8A7B82824E4377E47EF9C41,
	XRGeneralSettings_Quit_mD6E708EB9FA9A52EDAF992CD04089A5E23522C60,
	XRGeneralSettings_Start_m3236D327A4A3E66527CEBDA2F5BDD07D01B71EA5,
	XRGeneralSettings_OnDestroy_mF1FAFD114FDDAF476767A2EDA9171942E4DCF17E,
	XRGeneralSettings_AttemptInitializeXRSDKOnLoad_mC7F0EFAC852684103350BC26B573F1E085707EAD,
	XRGeneralSettings_AttemptStartXRSDKOnBeforeSplashScreen_m4D982B772260F4FFB51456402EA7DD993181FBCD,
	XRGeneralSettings_InitXRSDK_m7E948591C80EC7A2A97417A959BEA5DF4BACB58D,
	XRGeneralSettings_StartXRSDK_mE58ED248C7E672773A4D9FF8BBECEC0DBE2D0059,
	XRGeneralSettings_StopXRSDK_m0307D54FDB9513DD49B5523D7FEC72513DE7E47F,
	XRGeneralSettings_DeInitXRSDK_m736781E104A1DBBFFE393393B0ADFBCB9F164EED,
	XRGeneralSettings__ctor_mF398EFC4AD993C540516487FC50F83C2468DFB3A,
	XRGeneralSettings__cctor_m3894F3807749E1AA75D5D4995DD41CB3DCE5C44D,
	XRLoader_Initialize_m5E528D0A51C1AD2732689F548B99E1A88470BD02,
	XRLoader_Start_mBA33843711A6DFB08AC623A2F2892FD71CB1DDE7,
	XRLoader_Stop_m2E7F152C1FAF60294D7A95E077719AF493869894,
	XRLoader_Deinitialize_m863CE4A82FE431245E25BA85C04DC3F0E8E88CDA,
	NULL,
	XRLoader_GetSupportedGraphicsDeviceTypes_m322533865DF60C4FD1F029988C4C4AEF1925FD5E,
	XRLoader__ctor_m9F3AB0D960DC1395FBBF3D0D65EB27E70662B4B8,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	XRLoaderHelper_Deinitialize_m46197AF56BC868F789B95FD1702F58BB4265A376,
	XRLoaderHelper__ctor_m61180EE7C9A2091D2120E4FCBA1A022333248FD6,
	XRManagerSettings_get_automaticLoading_mDCB2A7289C4FE8BD7FBA7CA207CE4EEE14C19CA9,
	XRManagerSettings_set_automaticLoading_mF7787829863EF4D75DC56716E9283C9D456030DD,
	XRManagerSettings_get_automaticRunning_mDC0FE3222A77630AB1D51AA0811CCA3132024C59,
	XRManagerSettings_set_automaticRunning_m0B46221356F33FFE168DACAA8812E938036FD439,
	XRManagerSettings_get_loaders_mBD4F29A6F89D5D620634FC1853A88257FA58AE36,
	XRManagerSettings_get_isInitializationComplete_m878C7DDB712D4F99160B2F7C71CBFC201F5AB63F,
	XRManagerSettings_get_activeLoader_m9371C31D367F55202EE948306D0C61A9D8725B67,
	XRManagerSettings_set_activeLoader_m4961B290666B1461944FD0487DECB699A903D8D3,
	NULL,
	XRManagerSettings_InitializeLoaderSync_mC8931AA78045796B6C9CFCF8CAF6FB0B54C40025,
	XRManagerSettings_InitializeLoader_m6AE56C59F2EDD415911272B417E0085F6009667F,
	XRManagerSettings_CheckGraphicsAPICompatibility_m17471A8679FF7F6CD90FFB12D036A5075DF3F8C1,
	XRManagerSettings_StartSubsystems_m3A10751468041448DBCB179136F3313FEA29537F,
	XRManagerSettings_StopSubsystems_m1B4A77F81B323A476A1446FF1AD1B3F2482FB7A9,
	XRManagerSettings_DeinitializeLoader_mAEB6EFBBDB20076FC3B7DB17D7B2FAA34E2C5E2C,
	XRManagerSettings_Start_m318DCEC189E13498E539AD0FD1411F006ADFC987,
	XRManagerSettings_OnDisable_mBF327F3EF9A66EE05ABFFF207440B683CBC9A25E,
	XRManagerSettings_OnDestroy_m0D6707A5F61284A0BB3808ABBEB8EEA82C92452A,
	XRManagerSettings__ctor_mC1B877CD102E57833EE8D4811A9424598F34078B,
	XRManagerSettings__cctor_m6AEE40CBB054335113BCA1BE4C4DAA4DFCD4BF99,
	U3CInitializeLoaderU3Ed__21__ctor_mE1EFD8B0AE006E71FC3596E10AB1BFAC6B7570E1,
	U3CInitializeLoaderU3Ed__21_System_IDisposable_Dispose_m3D0F83E1A23AF0F08427EF6C1FC7FBB8BCA5FE4D,
	U3CInitializeLoaderU3Ed__21_MoveNext_mC17EDB30580E987D970F6F6AB785210EF7FE5AA2,
	U3CInitializeLoaderU3Ed__21_U3CU3Em__Finally1_m8B409C7A2D9E4222422F06BFEC8DF4D3F1187747,
	U3CInitializeLoaderU3Ed__21_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mBC84CBAC26C6E31E3B7368934B5DE21A94FE484B,
	U3CInitializeLoaderU3Ed__21_System_Collections_IEnumerator_Reset_mA8F74EB916C42DF0855C5110619D38843142C4E4,
	U3CInitializeLoaderU3Ed__21_System_Collections_IEnumerator_get_Current_m6332A8667B15EA740D7E8F292B2F324594C31F60,
};
static const int32_t s_InvokerIndices[66] = 
{
	14,
	26,
	14,
	26,
	23,
	27,
	14,
	26,
	4,
	14,
	102,
	23,
	3,
	23,
	23,
	3,
	3,
	23,
	23,
	23,
	23,
	23,
	3,
	102,
	102,
	102,
	102,
	-1,
	302,
	23,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	102,
	23,
	102,
	31,
	102,
	31,
	14,
	102,
	14,
	26,
	-1,
	23,
	14,
	9,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	3,
	32,
	23,
	102,
	23,
	14,
	23,
	14,
};
static const Il2CppTokenRangePair s_rgctxIndices[8] = 
{
	{ 0x0600001F, { 0, 2 } },
	{ 0x06000020, { 2, 2 } },
	{ 0x06000021, { 4, 2 } },
	{ 0x06000022, { 6, 2 } },
	{ 0x06000023, { 8, 8 } },
	{ 0x06000024, { 16, 1 } },
	{ 0x06000025, { 17, 1 } },
	{ 0x06000030, { 18, 1 } },
};
static const Il2CppRGCTXDefinition s_rgctxValues[19] = 
{
	{ (Il2CppRGCTXDataType)1, 11944 },
	{ (Il2CppRGCTXDataType)2, 11944 },
	{ (Il2CppRGCTXDataType)3, 7550 },
	{ (Il2CppRGCTXDataType)2, 13676 },
	{ (Il2CppRGCTXDataType)3, 7551 },
	{ (Il2CppRGCTXDataType)2, 13677 },
	{ (Il2CppRGCTXDataType)3, 7552 },
	{ (Il2CppRGCTXDataType)2, 13678 },
	{ (Il2CppRGCTXDataType)3, 7553 },
	{ (Il2CppRGCTXDataType)3, 7554 },
	{ (Il2CppRGCTXDataType)3, 7555 },
	{ (Il2CppRGCTXDataType)3, 7556 },
	{ (Il2CppRGCTXDataType)2, 11946 },
	{ (Il2CppRGCTXDataType)1, 13679 },
	{ (Il2CppRGCTXDataType)3, 7557 },
	{ (Il2CppRGCTXDataType)2, 13680 },
	{ (Il2CppRGCTXDataType)3, 7558 },
	{ (Il2CppRGCTXDataType)3, 7559 },
	{ (Il2CppRGCTXDataType)2, 11953 },
};
extern const Il2CppCodeGenModule g_Unity_XR_ManagementCodeGenModule;
const Il2CppCodeGenModule g_Unity_XR_ManagementCodeGenModule = 
{
	"Unity.XR.Management.dll",
	66,
	s_methodPointers,
	s_InvokerIndices,
	0,
	NULL,
	8,
	s_rgctxIndices,
	19,
	s_rgctxValues,
	NULL,
};
